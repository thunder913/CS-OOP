﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExplicitInterfaces
{
    public interface INameable
    {
        string Name { get; set; }
    }
}
