﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IAgeable
    {
        int Age { get; set; }
    }
}
