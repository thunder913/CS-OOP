﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IName
    {
        string Name { get; set; }
    }
}
